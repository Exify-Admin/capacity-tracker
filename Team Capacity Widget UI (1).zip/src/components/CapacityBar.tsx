import React from 'react';
import { AlertTriangle } from 'lucide-react';

interface CapacityBarProps {
  active: number;
  total: number;
  className?: string;
}

export function CapacityBar({ active, total, className = '' }: CapacityBarProps) {
  const percentage = Math.round((active / total) * 100);
  const isNearLimit = active >= 8 && active <= total - 1;
  const isOverCapacity = active > total;
  const blocksToShow = Math.min(active, total);
  const overflowBlocks = Math.max(0, active - total);

  return (
    <div className={className}>
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-[11px] text-gray-500">Active Tasks</span>
        <div className="flex items-center gap-1.5">
          <span className="text-[13px] text-gray-700">
            {active} / {total}
          </span>
          <span className="text-[13px] text-gray-500">{percentage}%</span>
        </div>
      </div>
      <div className="flex items-center gap-0.5">
        <div className="flex gap-0.5">
          {Array.from({ length: total }).map((_, i) => (
            <div
              key={i}
              className={`h-5 w-full rounded-sm transition-colors ${
                i < blocksToShow
                  ? isNearLimit
                    ? 'bg-amber-400'
                    : 'bg-gray-800'
                  : 'bg-gray-100'
              }`}
              style={{ minWidth: '8px', width: '100%' }}
            />
          ))}
        </div>
        {isOverCapacity && (
          <>
            <div className="flex gap-0.5 ml-0.5">
              {Array.from({ length: overflowBlocks }).map((_, i) => (
                <div
                  key={`overflow-${i}`}
                  className="h-5 rounded-sm bg-red-500"
                  style={{ minWidth: '8px', width: '8px' }}
                />
              ))}
            </div>
            <AlertTriangle className="w-3.5 h-3.5 text-red-500 ml-1.5" />
          </>
        )}
      </div>
    </div>
  );
}
