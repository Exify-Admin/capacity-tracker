import React, { useState } from 'react';
import { TaskBar, Task } from './TaskBar';

export interface FinalTeamMember {
  id: string;
  name: string;
  role: string;
  avatar: string;
  currentProject: string;
  tasks: Task[];
}

interface FinalCapacityRowProps {
  member: FinalTeamMember;
  onTaskClick?: (task: Task) => void;
  onMarkUnblocked?: (taskId: string) => void;
  onAddComment?: (taskId: string) => void;
  onOpenInNotion?: (taskId: string) => void;
}

export function FinalCapacityRow({
  member,
  onTaskClick,
  onMarkUnblocked,
  onAddComment,
  onOpenInNotion,
}: FinalCapacityRowProps) {
  const [isHovered, setIsHovered] = useState(false);

  // Calculate metrics
  const wipTasks = member.tasks.filter(
    (t) => t.status === 'In Progress' || t.status === 'Blocked'
  );
  const wipCount = wipTasks.length;
  const wipLimit = 10;

  const queueTasks = member.tasks.filter((t) => t.status === 'Not Started');
  const queueCount = queueTasks.length;
  const queueLimit = 5;

  // Get current task (left-most segment = highest priority)
  const sortedTasks = [...member.tasks].sort((a, b) => {
    const priority = {
      'In Progress': 0,
      'Blocked': 1,
      'Not Started': 2,
    };
    return priority[a.status] - priority[b.status];
  });
  const currentTask = sortedTasks[0];

  return (
    <div
      className={`relative transition-colors ${
        isHovered ? 'bg-gray-50/60' : ''
      }`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Desktop layout - single row */}
      <div className="hidden lg:grid grid-cols-12 gap-4 items-center py-3 px-4">
        {/* LEFT: Person column (fixed width) */}
        <div className="col-span-2 flex items-start gap-2.5">
          <div
            className="w-8 h-8 rounded-full bg-gray-200 flex-shrink-0 overflow-hidden mt-0.5"
            style={{
              backgroundImage: `url(${member.avatar})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          />
          <div className="min-w-0 flex-1">
            <div className="text-[10px] text-gray-500 truncate mb-0.5">
              Current Project • {member.currentProject}
            </div>
            <div className="font-semibold text-[13px] text-gray-900 truncate">
              {member.name}
            </div>
            <div className="text-[11px] text-gray-500 truncate">{member.role}</div>
          </div>
        </div>

        {/* MIDDLE: Task bar column (primary visual) */}
        <div className="col-span-4">
          <TaskBar 
            tasks={member.tasks} 
            onTaskClick={onTaskClick}
            onMarkUnblocked={onMarkUnblocked}
            onAddComment={onAddComment}
            onOpenInNotion={onOpenInNotion}
          />
        </div>

        {/* Metrics */}
        <div className="col-span-2 flex items-center gap-2">
          <span className="text-[13px] text-gray-700 whitespace-nowrap">
            WIP {wipCount}/{wipLimit}
          </span>
          <span className="text-[13px] text-gray-400">•</span>
          <span
            className={`px-2 py-0.5 rounded-md text-[11px] font-medium whitespace-nowrap ${
              queueCount > queueLimit
                ? 'bg-red-500 text-white'
                : 'bg-green-500 text-white'
            }`}
          >
            Queue {queueCount}/{queueLimit}
          </span>
        </div>

        {/* Current Task */}
        <div className="col-span-4">
          {currentTask ? (
            <button
              onClick={() => onTaskClick?.(currentTask)}
              className="text-[12px] text-gray-600 hover:text-gray-900 truncate w-full text-left"
            >
              <span className="text-gray-500">Current task:</span>{' '}
              {currentTask.name}
            </button>
          ) : (
            <div className="text-[12px] text-gray-500 truncate">
              Current task: —
            </div>
          )}
        </div>
      </div>

      {/* Tablet/Mobile layout - two lines */}
      <div className="lg:hidden py-3 px-4 space-y-2">
        {/* Line 1: Name block + metrics */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-2.5 flex-1 min-w-0">
            <div
              className="w-8 h-8 rounded-full bg-gray-200 flex-shrink-0 overflow-hidden"
              style={{
                backgroundImage: `url(${member.avatar})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
              }}
            />
            <div className="min-w-0 flex-1">
              <div className="text-[10px] text-gray-500 truncate mb-0.5">
                Current Project • {member.currentProject}
              </div>
              <div className="font-semibold text-[13px] text-gray-900 truncate">
                {member.name}
              </div>
              <div className="text-[11px] text-gray-500 truncate">{member.role}</div>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <span className="text-[13px] text-gray-700 whitespace-nowrap">
              WIP {wipCount}/{wipLimit}
            </span>
            <span className="text-[13px] text-gray-400">•</span>
            <span
              className={`px-2 py-0.5 rounded-md text-[11px] font-medium whitespace-nowrap ${
                queueCount > queueLimit
                  ? 'bg-red-500 text-white'
                  : 'bg-green-500 text-white'
              }`}
            >
              Queue {queueCount}/{queueLimit}
            </span>
          </div>
        </div>

        {/* Line 2: Bar + Current task */}
        <div className="space-y-1.5">
          <TaskBar 
            tasks={member.tasks} 
            onTaskClick={onTaskClick}
            onMarkUnblocked={onMarkUnblocked}
            onAddComment={onAddComment}
            onOpenInNotion={onOpenInNotion}
          />
          {currentTask && (
            <button
              onClick={() => onTaskClick?.(currentTask)}
              className="text-[12px] text-gray-600 hover:text-gray-900 truncate w-full text-left"
            >
              <span className="text-gray-500">Current task:</span>{' '}
              {currentTask.name}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}