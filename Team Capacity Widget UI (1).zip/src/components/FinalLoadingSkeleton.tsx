import React from 'react';

export function FinalLoadingSkeleton() {
  return (
    <div className="divide-y divide-gray-100">
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} className="grid grid-cols-12 gap-4 items-center py-3 px-4 animate-pulse">
          {/* Person column */}
          <div className="col-span-2 flex items-start gap-2.5">
            <div className="w-8 h-8 rounded-full bg-gray-200 flex-shrink-0" />
            <div className="flex-1 space-y-1.5">
              <div className="h-2 bg-gray-100 rounded w-3/4" />
              <div className="h-3 bg-gray-200 rounded w-full" />
              <div className="h-2.5 bg-gray-100 rounded w-2/3" />
            </div>
          </div>

          {/* Bar column */}
          <div className="col-span-4">
            <div className="flex gap-0.5">
              {Array.from({ length: 10 }).map((_, j) => (
                <div key={j} className="h-6 bg-gray-200 rounded-sm flex-1" />
              ))}
            </div>
          </div>

          {/* Metrics column */}
          <div className="col-span-2 flex gap-2">
            <div className="h-3 bg-gray-200 rounded w-16" />
            <div className="h-5 bg-gray-200 rounded-md w-20" />
          </div>

          {/* Current task column */}
          <div className="col-span-4">
            <div className="h-2.5 bg-gray-100 rounded w-full" />
          </div>
        </div>
      ))}
    </div>
  );
}
