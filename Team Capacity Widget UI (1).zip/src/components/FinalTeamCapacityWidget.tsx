import React, { useState } from 'react';
import { FinalCapacityRow, FinalTeamMember } from './FinalCapacityRow';
import { Task } from './TaskBar';
import { FinalLoadingSkeleton } from './FinalLoadingSkeleton';
import { FinalEmptyState } from './FinalEmptyState';
import { Search, ChevronDown } from 'lucide-react';

const mockFinalTeamMembers: FinalTeamMember[] = [
  {
    id: '1',
    name: 'Sarah Chen',
    role: 'Design',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
    currentProject: 'Website Refresh',
    tasks: [
      {
        id: 't1',
        name: 'Draft Q1 landing page copy and hero section',
        status: 'In Progress',
        dueDate: 'Jan 10',
        isOverdue: false,
        priority: 'P1',
      },
      {
        id: 't2',
        name: 'Design mobile navigation mockups',
        status: 'In Progress',
        dueDate: 'Jan 8',
        isOverdue: true,
        priority: 'P2',
      },
      {
        id: 't3',
        name: 'Review brand guidelines document',
        status: 'Blocked',
        dueDate: 'Jan 12',
        isOverdue: false,
        priority: 'P1',
      },
      {
        id: 't4',
        name: 'Create icon set for dashboard',
        status: 'Not Started',
        dueDate: 'Jan 15',
        isOverdue: false,
        priority: 'P3',
      },
      {
        id: 't5',
        name: 'Update design system tokens',
        status: 'Not Started',
        dueDate: 'Jan 16',
        isOverdue: false,
        priority: 'P3',
      },
      {
        id: 't6',
        name: 'Prototype checkout flow',
        status: 'Not Started',
        dueDate: 'Jan 18',
        isOverdue: false,
        priority: 'P2',
      },
    ],
  },
  {
    id: '2',
    name: 'Marcus Lee',
    role: 'Engineering',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
    currentProject: 'Mobile App',
    tasks: [
      {
        id: 't7',
        name: 'Implement authentication flow for iOS',
        status: 'In Progress',
        dueDate: 'Jan 9',
        isOverdue: false,
        priority: 'P1',
      },
      {
        id: 't8',
        name: 'Fix rate limiting issues in production',
        status: 'In Progress',
        dueDate: 'Jan 7',
        isOverdue: true,
        priority: 'P1',
      },
      {
        id: 't9',
        name: 'Debug API timeout errors',
        status: 'In Progress',
        dueDate: 'Jan 8',
        isOverdue: true,
        priority: 'P2',
      },
      {
        id: 't10',
        name: 'Refactor user settings module',
        status: 'Blocked',
        dueDate: 'Jan 11',
        isOverdue: false,
        priority: 'P2',
      },
      {
        id: 't11',
        name: 'Add unit tests for payment flow',
        status: 'Blocked',
        dueDate: 'Jan 10',
        isOverdue: true,
        priority: 'P1',
      },
      {
        id: 't12',
        name: 'Update dependency versions',
        status: 'Not Started',
        dueDate: 'Jan 14',
        isOverdue: false,
        priority: 'P3',
      },
      {
        id: 't13',
        name: 'Optimize image loading',
        status: 'Not Started',
        dueDate: 'Jan 16',
        isOverdue: false,
        priority: 'P3',
      },
      {
        id: 't14',
        name: 'Migrate to new API endpoints',
        status: 'Not Started',
        dueDate: 'Jan 17',
        isOverdue: false,
        priority: 'P2',
      },
    ],
  },
  {
    id: '3',
    name: 'Emma Davis',
    role: 'Marketing',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
    currentProject: 'Product Launch',
    tasks: [
      {
        id: 't15',
        name: 'Prepare email campaign templates',
        status: 'In Progress',
        dueDate: 'Jan 9',
        isOverdue: false,
        priority: 'P1',
      },
      {
        id: 't16',
        name: 'Schedule social media posts',
        status: 'In Progress',
        dueDate: 'Jan 8',
        isOverdue: false,
        priority: 'P2',
      },
      {
        id: 't17',
        name: 'Coordinate with PR team',
        status: 'Not Started',
        dueDate: 'Jan 12',
        isOverdue: false,
        priority: 'P3',
      },
      {
        id: 't18',
        name: 'Draft press release',
        status: 'Not Started',
        dueDate: 'Jan 13',
        isOverdue: false,
        priority: 'P2',
      },
      {
        id: 't19',
        name: 'Update website copy',
        status: 'Not Started',
        dueDate: 'Jan 15',
        isOverdue: false,
        priority: 'P3',
      },
      {
        id: 't20',
        name: 'Create launch checklist',
        status: 'Not Started',
        dueDate: 'Jan 16',
        isOverdue: false,
        priority: 'P3',
      },
      {
        id: 't21',
        name: 'Review analytics dashboard',
        status: 'Not Started',
        dueDate: 'Jan 17',
        isOverdue: false,
        priority: 'P3',
      },
    ],
  },
  {
    id: '4',
    name: 'Alex Kim',
    role: 'Engineering',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
    currentProject: 'API Platform',
    tasks: Array.from({ length: 14 }, (_, i) => ({
      id: `t${22 + i}`,
      name: `Task ${i + 1}: Platform development work item`,
      status: (i < 6 ? 'In Progress' : i < 9 ? 'Blocked' : 'Not Started') as 'In Progress' | 'Blocked' | 'Not Started',
      dueDate: `Jan ${8 + i}`,
      isOverdue: i < 3,
      priority: (i < 5 ? 'P1' : i < 10 ? 'P2' : 'P3') as 'P1' | 'P2' | 'P3',
    })),
  },
  {
    id: '5',
    name: 'Olivia Martinez',
    role: 'Design',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop',
    currentProject: 'Settings Redesign',
    tasks: [
      {
        id: 't36',
        name: 'Create wireframes for navigation flow',
        status: 'In Progress',
        dueDate: 'Jan 11',
        isOverdue: false,
        priority: 'P1',
      },
      {
        id: 't37',
        name: 'Design user preferences panel',
        status: 'In Progress',
        dueDate: 'Jan 9',
        isOverdue: false,
        priority: 'P2',
      },
      {
        id: 't38',
        name: 'Build interactive prototype',
        status: 'Not Started',
        dueDate: 'Jan 14',
        isOverdue: false,
        priority: 'P3',
      },
      {
        id: 't39',
        name: 'Conduct user testing',
        status: 'Not Started',
        dueDate: 'Jan 16',
        isOverdue: false,
        priority: 'P2',
      },
      {
        id: 't40',
        name: 'Refine visual design',
        status: 'Not Started',
        dueDate: 'Jan 18',
        isOverdue: false,
        priority: 'P3',
      },
    ],
  },
  {
    id: '6',
    name: 'James Wilson',
    role: 'Ops',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop',
    currentProject: 'Vendor Management',
    tasks: [
      {
        id: 't41',
        name: 'Review vendor contracts and pricing',
        status: 'In Progress',
        dueDate: 'Jan 10',
        isOverdue: false,
        priority: 'P1',
      },
      {
        id: 't42',
        name: 'Negotiate SLA terms',
        status: 'Not Started',
        dueDate: 'Jan 13',
        isOverdue: false,
        priority: 'P2',
      },
      {
        id: 't43',
        name: 'Audit security compliance',
        status: 'Not Started',
        dueDate: 'Jan 15',
        isOverdue: false,
        priority: 'P1',
      },
    ],
  },
  {
    id: '7',
    name: 'Sophia Taylor',
    role: 'Marketing',
    avatar: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop',
    currentProject: 'Social Media',
    tasks: [
      {
        id: 't44',
        name: 'Coordinate Q1 content calendar',
        status: 'In Progress',
        dueDate: 'Jan 9',
        isOverdue: false,
        priority: 'P1',
      },
      {
        id: 't45',
        name: 'Create Instagram story templates',
        status: 'In Progress',
        dueDate: 'Jan 8',
        isOverdue: true,
        priority: 'P2',
      },
      {
        id: 't46',
        name: 'Write blog post drafts',
        status: 'Blocked',
        dueDate: 'Jan 11',
        isOverdue: false,
        priority: 'P2',
      },
      {
        id: 't47',
        name: 'Schedule newsletter campaign',
        status: 'Not Started',
        dueDate: 'Jan 14',
        isOverdue: false,
        priority: 'P3',
      },
      {
        id: 't48',
        name: 'Analyze engagement metrics',
        status: 'Not Started',
        dueDate: 'Jan 16',
        isOverdue: false,
        priority: 'P3',
      },
      {
        id: 't49',
        name: 'Plan influencer outreach',
        status: 'Not Started',
        dueDate: 'Jan 17',
        isOverdue: false,
        priority: 'P2',
      },
    ],
  },
  {
    id: '8',
    name: 'Daniel Brown',
    role: 'Engineering',
    avatar: 'https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=100&h=100&fit=crop',
    currentProject: 'Analytics Dashboard',
    tasks: [
      {
        id: 't50',
        name: 'Optimize database query performance',
        status: 'In Progress',
        dueDate: 'Jan 10',
        isOverdue: false,
        priority: 'P1',
      },
      {
        id: 't51',
        name: 'Build custom metrics visualization',
        status: 'In Progress',
        dueDate: 'Jan 11',
        isOverdue: false,
        priority: 'P2',
      },
      {
        id: 't52',
        name: 'Implement data export feature',
        status: 'Not Started',
        dueDate: 'Jan 14',
        isOverdue: false,
        priority: 'P3',
      },
      {
        id: 't53',
        name: 'Add real-time updates',
        status: 'Not Started',
        dueDate: 'Jan 16',
        isOverdue: false,
        priority: 'P2',
      },
    ],
  },
];

export function FinalTeamCapacityWidget() {
  const [teamMembers] = useState(mockFinalTeamMembers);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('All Departments');
  const [selectedProject, setSelectedProject] = useState('All Projects');
  const [showDepartmentDropdown, setShowDepartmentDropdown] = useState(false);
  const [showProjectDropdown, setShowProjectDropdown] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const departments = ['All Departments', 'Engineering', 'Design', 'Marketing', 'Ops'];
  const projects = [
    'All Projects',
    'Website Refresh',
    'Mobile App',
    'Product Launch',
    'API Platform',
    'Settings Redesign',
    'Vendor Management',
    'Social Media',
    'Analytics Dashboard',
  ];

  // Calculate team totals
  const teamTotals = teamMembers.reduce(
    (acc, member) => {
      const wip = member.tasks.filter(
        (t) => t.status === 'In Progress' || t.status === 'Blocked'
      ).length;
      const queue = member.tasks.filter((t) => t.status === 'Not Started').length;
      const overdue = member.tasks.filter((t) => t.isOverdue).length;
      const blocked = member.tasks.filter((t) => t.status === 'Blocked').length;

      return {
        wip: acc.wip + wip,
        queue: acc.queue + queue,
        overdue: acc.overdue + overdue,
        blocked: acc.blocked + blocked,
      };
    },
    { wip: 0, queue: 0, overdue: 0, blocked: 0 }
  );

  const filteredMembers = teamMembers.filter((member) => {
    const matchesSearch = member.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDepartment = 
      selectedDepartment === 'All Departments' || 
      member.role === selectedDepartment;
    const matchesProject = 
      selectedProject === 'All Projects' || 
      member.currentProject === selectedProject;
    return matchesSearch && matchesDepartment && matchesProject;
  });

  const handleTaskClick = (task: Task) => {
    console.log('Task clicked:', task);
    // In production, this would open the task in Notion
  };

  const handleMarkBlocked = (taskId: string) => {
    console.log('Mark blocked:', taskId);
    // In production, this would update the task status to Blocked via Notion API
  };

  const handleMarkUnblocked = (taskId: string) => {
    console.log('Mark unblocked:', taskId);
    // In production, this would update the task status to In Progress via Notion API
  };

  const handleAddComment = (taskId: string) => {
    console.log('Add comment:', taskId);
    // In production, this would open comment modal or redirect to Notion
  };

  const handleOpenInNotion = (taskId: string) => {
    console.log('Open in Notion:', taskId);
    // In production, this would open the task page in Notion
  };

  return (
    <div className="w-full h-full bg-transparent flex flex-col">
      {/* Header */}
      <div className="px-4 py-3 border-b border-gray-200 flex-shrink-0">
        <div className="flex items-center justify-between">
          {/* Left: Title + Timestamp */}
          <div>
            <h1 className="font-semibold text-[15px] text-gray-900">Team Capacity</h1>
            <div className="text-[11px] text-gray-400 mt-0.5">Updated 2m ago</div>
          </div>

          {/* Right: Controls */}
          <div className="flex items-center gap-2">
            {/* Project Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowProjectDropdown(!showProjectDropdown)}
                className="px-2.5 py-1 bg-gray-100 hover:bg-gray-200 text-[12px] text-gray-700 rounded-md transition-colors flex items-center gap-1.5"
              >
                {selectedProject}
                <ChevronDown className="w-3 h-3" />
              </button>

              {/* Dropdown Menu */}
              {showProjectDropdown && (
                <div className="absolute top-full right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg py-1 z-50 min-w-[160px]">
                  {projects.map((proj) => (
                    <button
                      key={proj}
                      onClick={() => {
                        setSelectedProject(proj);
                        setShowProjectDropdown(false);
                      }}
                      className={`w-full px-3 py-1.5 text-left text-[12px] hover:bg-gray-50 transition-colors ${
                        proj === selectedProject
                          ? 'text-gray-900 font-medium'
                          : 'text-gray-600'
                      }`}
                    >
                      {proj}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Department Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowDepartmentDropdown(!showDepartmentDropdown)}
                className="px-2.5 py-1 bg-gray-100 hover:bg-gray-200 text-[12px] text-gray-700 rounded-md transition-colors flex items-center gap-1.5"
              >
                {selectedDepartment}
                <ChevronDown className="w-3 h-3" />
              </button>

              {/* Dropdown Menu */}
              {showDepartmentDropdown && (
                <div className="absolute top-full right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg py-1 z-50 min-w-[160px]">
                  {departments.map((dept) => (
                    <button
                      key={dept}
                      onClick={() => {
                        setSelectedDepartment(dept);
                        setShowDepartmentDropdown(false);
                      }}
                      className={`w-full px-3 py-1.5 text-left text-[12px] hover:bg-gray-50 transition-colors ${
                        dept === selectedDepartment
                          ? 'text-gray-900 font-medium'
                          : 'text-gray-600'
                      }`}
                    >
                      {dept}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Search */}
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
              <input
                type="text"
                placeholder="Search teammate…"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1 bg-gray-50 border border-gray-200 rounded-md text-[12px] w-40 focus:outline-none focus:ring-1 focus:ring-gray-300"
              />
            </div>
          </div>
        </div>

        {/* Team Totals Strip */}
        <div className="text-[11px] text-gray-500">
          <span className="mr-3">WIP {teamTotals.wip}</span>
          <span className="mr-3">• Queue {teamTotals.queue}</span>
          <span className="mr-3">• Overdue {teamTotals.overdue}</span>
          <span>• Blocked {teamTotals.blocked}</span>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden">
        {isLoading ? (
          <FinalLoadingSkeleton />
        ) : filteredMembers.length > 0 ? (
          <div className="divide-y divide-gray-100">
            {filteredMembers.map((member) => (
              <FinalCapacityRow
                key={member.id}
                member={member}
                onTaskClick={handleTaskClick}
                onMarkBlocked={handleMarkBlocked}
                onMarkUnblocked={handleMarkUnblocked}
                onAddComment={handleAddComment}
                onOpenInNotion={handleOpenInNotion}
              />
            ))}
          </div>
        ) : (
          <FinalEmptyState />
        )}
      </div>
    </div>
  );
}