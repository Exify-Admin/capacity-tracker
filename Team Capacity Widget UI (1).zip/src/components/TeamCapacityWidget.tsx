import React, { useState } from 'react';
import { CapacityRow, TeamMember } from './CapacityRow';
import { Toast } from './Toast';
import { Search } from 'lucide-react';

const mockTeamMembers: TeamMember[] = [
  {
    id: '1',
    name: 'Sarah Chen',
    role: 'Design',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
    activeTasks: 6,
    capacity: 10,
    blocked: 1,
    overdue: 0,
    topTask: 'Draft Q1 landing page copy and hero section…',
  },
  {
    id: '2',
    name: 'Marcus Lee',
    role: 'Engineering',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
    activeTasks: 9,
    capacity: 10,
    blocked: 0,
    overdue: 2,
    topTask: 'Implement authentication flow for mobile app…',
  },
  {
    id: '3',
    name: 'Emma Davis',
    role: 'Marketing',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
    activeTasks: 4,
    capacity: 10,
    blocked: 0,
    overdue: 0,
    topTask: 'Prepare email campaign for product launch…',
  },
  {
    id: '4',
    name: 'Alex Kim',
    role: 'Engineering',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
    activeTasks: 11,
    capacity: 10,
    blocked: 2,
    overdue: 1,
    topTask: 'Debug API rate limiting issues in production…',
  },
  {
    id: '5',
    name: 'Olivia Martinez',
    role: 'Design',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop',
    activeTasks: 7,
    capacity: 10,
    blocked: 0,
    overdue: 0,
    topTask: 'Create wireframes for settings page redesign…',
  },
  {
    id: '6',
    name: 'James Wilson',
    role: 'Ops',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop',
    activeTasks: 3,
    capacity: 10,
    blocked: 0,
    overdue: 0,
    topTask: 'Review vendor contracts and negotiate terms…',
  },
  {
    id: '7',
    name: 'Sophia Taylor',
    role: 'Marketing',
    avatar: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop',
    activeTasks: 8,
    capacity: 10,
    blocked: 1,
    overdue: 0,
    topTask: 'Coordinate social media content calendar…',
  },
  {
    id: '8',
    name: 'Daniel Brown',
    role: 'Engineering',
    avatar: 'https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=100&h=100&fit=crop',
    activeTasks: 5,
    capacity: 10,
    blocked: 0,
    overdue: 0,
    topTask: 'Optimize database queries for analytics dashboard…',
  },
];

interface ToastState {
  show: boolean;
  message: string;
  type: 'success' | 'error';
  onAction?: () => void;
}

export function TeamCapacityWidget() {
  const [teamMembers, setTeamMembers] = useState(mockTeamMembers);
  const [savingMemberId, setSavingMemberId] = useState<string | null>(null);
  const [toast, setToast] = useState<ToastState>({
    show: false,
    message: '',
    type: 'success',
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilters, setActiveFilters] = useState({
    timeframe: 'This Week',
    project: 'All Projects',
    status: 'Active Only',
  });

  const showToast = (message: string, type: 'success' | 'error', onAction?: () => void) => {
    setToast({ show: true, message, type, onAction });
  };

  const hideToast = () => {
    setToast({ show: false, message: '', type: 'success' });
  };

  const simulateSave = async (memberId: string, action: string) => {
    setSavingMemberId(memberId);
    
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 800));
    
    setSavingMemberId(null);
    
    // Randomly succeed or fail (90% success rate)
    if (Math.random() > 0.1) {
      showToast('Updated in Notion', 'success', () => {
        console.log('Undo action');
        hideToast();
      });
    } else {
      showToast('Update failed', 'error', () => {
        simulateSave(memberId, action);
        hideToast();
      });
    }
  };

  const handleMarkDone = (memberId: string) => {
    simulateSave(memberId, 'mark_done');
  };

  const handleToggleBlocked = (memberId: string) => {
    simulateSave(memberId, 'toggle_blocked');
  };

  const handleSnooze = (memberId: string) => {
    simulateSave(memberId, 'snooze');
  };

  const handleReassign = (memberId: string) => {
    simulateSave(memberId, 'reassign');
  };

  const handleSetPriority = (memberId: string) => {
    simulateSave(memberId, 'set_priority');
  };

  const handleOpenInNotion = (memberId: string) => {
    console.log('Opening in Notion:', memberId);
    window.open('https://notion.so', '_blank');
  };

  const filteredMembers = teamMembers.filter((member) =>
    member.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="w-full h-full bg-transparent">
      {/* Header */}
      <div className="px-4 py-3 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-baseline gap-2">
            <h1 className="font-semibold text-[15px] text-gray-900">Team Capacity</h1>
            <span className="text-[11px] text-gray-500">Live from Notion • Read/Write</span>
          </div>
          <div className="flex items-center gap-2">
            {/* Filter Chips */}
            <button className="px-2.5 py-1 bg-gray-100 hover:bg-gray-200 text-[12px] text-gray-700 rounded-md transition-colors">
              {activeFilters.timeframe}
            </button>
            <button className="px-2.5 py-1 bg-gray-100 hover:bg-gray-200 text-[12px] text-gray-700 rounded-md transition-colors">
              {activeFilters.project}
            </button>
            <button className="px-2.5 py-1 bg-gray-100 hover:bg-gray-200 text-[12px] text-gray-700 rounded-md transition-colors">
              {activeFilters.status}
            </button>
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
              <input
                type="text"
                placeholder="Search teammate…"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1 bg-gray-50 border border-gray-200 rounded-md text-[12px] w-40 focus:outline-none focus:ring-1 focus:ring-gray-300"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="divide-y divide-gray-100">
        {filteredMembers.length > 0 ? (
          filteredMembers.map((member) => (
            <CapacityRow
              key={member.id}
              member={member}
              onMarkDone={handleMarkDone}
              onToggleBlocked={handleToggleBlocked}
              onSnooze={handleSnooze}
              onReassign={handleReassign}
              onSetPriority={handleSetPriority}
              onOpenInNotion={handleOpenInNotion}
              isSaving={savingMemberId === member.id}
            />
          ))
        ) : (
          <div className="py-16 text-center">
            <p className="text-[13px] text-gray-500">No active tasks found.</p>
            <p className="text-[12px] text-gray-400 mt-1">Try adjusting filters.</p>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="px-4 py-2.5 border-t border-gray-200 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 bg-gray-800 rounded-sm" />
            <span className="text-[11px] text-gray-600">Within</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 bg-amber-400 rounded-sm" />
            <span className="text-[11px] text-gray-600">Near</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 bg-red-500 rounded-sm" />
            <span className="text-[11px] text-gray-600">Over</span>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[11px] text-gray-500">Updated 2m ago</span>
          <span className="text-[11px] text-gray-400">Actions update Notion via API</span>
        </div>
      </div>

      {/* Toast */}
      {toast.show && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={hideToast}
          onAction={toast.onAction}
          actionLabel={toast.type === 'success' ? 'Undo' : 'Retry'}
        />
      )}
    </div>
  );
}
