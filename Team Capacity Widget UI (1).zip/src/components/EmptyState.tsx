import React from 'react';

export function EmptyState() {
  return (
    <div className="py-20 text-center">
      <p className="text-[13px] text-gray-500 mb-1">No tasks match the current filters.</p>
      <p className="text-[12px] text-gray-400">Try switching to Not Started or clearing search.</p>
    </div>
  );
}
