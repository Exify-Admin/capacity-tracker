import React, { useState, useEffect, useRef } from 'react';
import { Ban } from 'lucide-react';

export interface Task {
  id: string;
  name: string;
  status: 'In Progress' | 'Blocked' | 'Not Started';
  dueDate: string;
  isOverdue: boolean;
  priority: 'P1' | 'P2' | 'P3';
}

interface TaskBarSegmentProps {
  task?: Task;
  isOverflow?: boolean;
  overflowCount?: number;
  onClick?: () => void;
  onMarkUnblocked?: (taskId: string) => void;
  onAddComment?: (taskId: string) => void;
  onOpenInNotion?: (taskId: string) => void;
}

export function TaskBarSegment({ 
  task, 
  isOverflow, 
  overflowCount, 
  onClick,
  onMarkUnblocked,
  onAddComment,
  onOpenInNotion,
}: TaskBarSegmentProps) {
  const [showPopover, setShowPopover] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const popoverRef = useRef<HTMLDivElement>(null);
  const segmentRef = useRef<HTMLDivElement>(null);

  // Close popover when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        popoverRef.current &&
        segmentRef.current &&
        !popoverRef.current.contains(event.target as Node) &&
        !segmentRef.current.contains(event.target as Node)
      ) {
        setShowPopover(false);
      }
    };

    if (showPopover) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showPopover]);

  const handleSegmentClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (task) {
      setShowPopover(!showPopover);
    }
    onClick?.();
  };

  if (isOverflow && overflowCount) {
    return (
      <div
        className="relative h-6 bg-red-500 rounded-sm flex items-center justify-center cursor-pointer hover:opacity-90 transition-opacity"
        style={{ flex: 1 }}
        onClick={onClick}
      >
        <span className="text-white text-[10px] font-semibold">+{overflowCount}</span>
      </div>
    );
  }

  if (!task) {
    return (
      <div
        className="h-6 bg-gray-100 rounded-sm"
        style={{ flex: 1 }}
      />
    );
  }

  const bgColor = task.status === 'Blocked' ? 'bg-yellow-400' : 'bg-green-500';
  const isBlocked = task.status === 'Blocked';

  // Priority pill styling
  const getPriorityStyle = (priority: string) => {
    switch (priority) {
      case 'P1':
        return 'bg-red-100 text-red-700 border-red-200';
      case 'P2':
        return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'P3':
        return 'bg-gray-100 text-gray-600 border-gray-200';
      default:
        return 'bg-gray-100 text-gray-600 border-gray-200';
    }
  };

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case 'P1':
        return 'P1 High';
      case 'P2':
        return 'P2 Medium';
      case 'P3':
        return 'P3 Low';
      default:
        return priority;
    }
  };

  return (
    <div className="relative" style={{ flex: 1 }}>
      <div
        ref={segmentRef}
        className={`h-6 ${bgColor} rounded-sm cursor-pointer relative transition-all duration-150 ${
          isHovered ? 'translate-y-[-2px] shadow-[0_0_0_2px_rgba(0,0,0,0.1)]' : ''
        }`}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        onClick={handleSegmentClick}
      >
        {/* Blocked icon overlay */}
        {task.status === 'Blocked' && (
          <div className="absolute inset-0 flex items-center justify-center">
            <Ban className="w-3 h-3 text-gray-800 opacity-70" strokeWidth={2} />
          </div>
        )}

        {/* Overdue corner marker */}
        {task.isOverdue && (
          <div className="absolute top-0 right-0 w-0 h-0 border-t-[6px] border-t-red-500 border-l-[6px] border-l-transparent" />
        )}
      </div>

      {/* Click-triggered Popover */}
      {showPopover && (
        <div 
          ref={popoverRef}
          className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 z-50"
        >
          <div className="bg-white border border-gray-200 rounded-lg shadow-lg text-[11px] w-64">
            {/* Task Name - Clickable */}
            <div className="px-3 pt-2.5 pb-2">
              <button
                onClick={() => {
                  onOpenInNotion?.(task.id);
                  setShowPopover(false);
                }}
                className="font-medium text-gray-900 hover:text-gray-600 text-left w-full line-clamp-2 mb-1.5"
              >
                {task.name}
              </button>
              
              {/* Meta row + Priority pill */}
              <div className="flex items-center gap-2 flex-wrap">
                <div className="text-[10px] text-gray-500">
                  {task.status}
                  {task.isOverdue && ' • Overdue'}
                  {' • Due: ' + task.dueDate}
                </div>
                <span
                  className={`px-1.5 py-0.5 rounded text-[9px] font-medium border ${getPriorityStyle(
                    task.priority
                  )}`}
                >
                  {getPriorityLabel(task.priority)}
                </span>
              </div>
            </div>

            {/* Divider */}
            <div className="border-t border-gray-100" />

            {/* Actions Row */}
            <div className="px-3 py-2 flex items-center gap-2 flex-wrap">
              {/* Only show Mark Unblocked if task is blocked */}
              {isBlocked && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onMarkUnblocked?.(task.id);
                    setShowPopover(false);
                  }}
                  className="px-2 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded text-[11px] transition-colors"
                >
                  Mark Unblocked
                </button>
              )}

              {/* Add Comment */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onAddComment?.(task.id);
                  setShowPopover(false);
                }}
                className="px-2 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded text-[11px] transition-colors"
              >
                Add Comment
              </button>
            </div>

            {/* Footer - Open in Notion */}
            <div className="border-t border-gray-100">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenInNotion?.(task.id);
                  setShowPopover(false);
                }}
                className="w-full px-3 py-2 text-[10px] text-gray-500 hover:text-gray-700 hover:bg-gray-50 transition-colors text-left rounded-b-lg"
              >
                Open task in Notion →
              </button>
            </div>
          </div>
          <div className="w-2 h-2 bg-white border-r border-b border-gray-200 absolute top-full left-1/2 -translate-x-1/2 -translate-y-1/2 rotate-45" />
        </div>
      )}
    </div>
  );
}