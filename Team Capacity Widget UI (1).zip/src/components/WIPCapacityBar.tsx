import React from 'react';
import { AlertTriangle } from 'lucide-react';

interface WIPCapacityBarProps {
  wip: number;
  total: number;
  className?: string;
}

export function WIPCapacityBar({ wip, total, className = '' }: WIPCapacityBarProps) {
  const percentage = Math.round((wip / total) * 100);
  const isNearLimit = wip >= 8 && wip <= total - 1;
  const isOverCapacity = wip > total;
  const blocksToShow = Math.min(wip, total);
  const overflowBlocks = Math.max(0, wip - total);

  return (
    <div className={className}>
      <div className="flex items-center mb-1.5">
        <span className="text-[11px] text-gray-500">WIP (In Progress)</span>
      </div>
      <div className="flex items-center gap-0.5">
        <div className="flex gap-0.5 flex-1">
          {Array.from({ length: total }).map((_, i) => (
            <div
              key={i}
              className={`h-5 rounded-sm transition-colors ${
                i < blocksToShow
                  ? isNearLimit
                    ? 'bg-amber-400'
                    : 'bg-gray-800'
                  : 'bg-gray-100'
              }`}
              style={{ minWidth: '7px', flex: 1 }}
            />
          ))}
        </div>
        {isOverCapacity && (
          <>
            <div className="flex gap-0.5 ml-0.5">
              {Array.from({ length: overflowBlocks }).map((_, i) => (
                <div
                  key={`overflow-${i}`}
                  className="h-5 rounded-sm bg-red-500"
                  style={{ minWidth: '7px', width: '7px' }}
                />
              ))}
            </div>
            <AlertTriangle className="w-3.5 h-3.5 text-red-500 ml-1" />
          </>
        )}
      </div>
    </div>
  );
}
