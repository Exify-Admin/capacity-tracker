import React from 'react';
import { TaskBarSegment, Task } from './TaskBarSegment';

export type { Task };

interface TaskBarProps {
  tasks: Task[];
  onTaskClick?: (task: Task) => void;
  onMarkUnblocked?: (taskId: string) => void;
  onAddComment?: (taskId: string) => void;
  onOpenInNotion?: (taskId: string) => void;
}

export function TaskBar({ 
  tasks, 
  onTaskClick,
  onMarkUnblocked,
  onAddComment,
  onOpenInNotion,
}: TaskBarProps) {
  const MAX_SEGMENTS = 10;
  
  // Sort tasks by priority to completion:
  // 1. In Progress (finish what's started)
  // 2. Blocked
  // 3. Not Started
  const sortedTasks = [...tasks].sort((a, b) => {
    const priority = {
      'In Progress': 0,
      'Blocked': 1,
      'Not Started': 2,
    };
    return priority[a.status] - priority[b.status];
  });

  const hasOverflow = sortedTasks.length > MAX_SEGMENTS;
  const visibleTasks = hasOverflow ? sortedTasks.slice(0, 9) : sortedTasks.slice(0, MAX_SEGMENTS);
  const overflowCount = hasOverflow ? sortedTasks.length - 9 : 0;
  const emptySegments = Math.max(0, MAX_SEGMENTS - visibleTasks.length - (hasOverflow ? 1 : 0));

  return (
    <div className="flex gap-0.5">
      {/* Visible task segments */}
      {visibleTasks.map((task) => (
        <TaskBarSegment
          key={task.id}
          task={task}
          onClick={() => onTaskClick?.(task)}
          onMarkUnblocked={onMarkUnblocked}
          onAddComment={onAddComment}
          onOpenInNotion={onOpenInNotion}
        />
      ))}

      {/* Overflow segment */}
      {hasOverflow && (
        <TaskBarSegment
          isOverflow
          overflowCount={overflowCount}
          onClick={() => console.log('Show overflow tasks')}
        />
      )}

      {/* Empty segments */}
      {Array.from({ length: emptySegments }).map((_, i) => (
        <TaskBarSegment key={`empty-${i}`} />
      ))}
    </div>
  );
}