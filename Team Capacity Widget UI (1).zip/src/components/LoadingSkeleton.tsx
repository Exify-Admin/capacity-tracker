import React from 'react';

export function LoadingSkeleton() {
  return (
    <div className="divide-y divide-gray-100">
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} className="grid grid-cols-12 gap-3 items-center py-2.5 px-4 animate-pulse">
          {/* Avatar + Name area */}
          <div className="col-span-3 flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-gray-200" />
            <div className="flex-1 space-y-1.5">
              <div className="h-3 bg-gray-200 rounded w-3/4" />
              <div className="h-2.5 bg-gray-100 rounded w-1/2" />
            </div>
          </div>

          {/* Bar area */}
          <div className="col-span-3">
            <div className="mb-1.5 h-2.5 bg-gray-100 rounded w-24" />
            <div className="flex gap-0.5">
              {Array.from({ length: 10 }).map((_, j) => (
                <div key={j} className="h-5 bg-gray-200 rounded-sm flex-1" />
              ))}
            </div>
          </div>

          {/* Metrics area */}
          <div className="col-span-2 space-y-1">
            <div className="h-3 bg-gray-200 rounded w-20" />
            <div className="h-2.5 bg-gray-100 rounded w-16" />
          </div>

          {/* Chips area */}
          <div className="col-span-2 flex gap-1">
            <div className="h-5 bg-gray-100 rounded-md w-16" />
          </div>

          {/* Due next area */}
          <div className="col-span-2">
            <div className="h-2.5 bg-gray-100 rounded w-full" />
          </div>
        </div>
      ))}
    </div>
  );
}
