import React from 'react';
import { FinalTeamCapacityWidget } from './components/FinalTeamCapacityWidget';

export default function App() {
  return (
    <div className="min-h-screen w-full bg-white flex items-center justify-center p-8">
      {/* Container showing the widget at different viewport sizes */}
      <div className="w-full max-w-[1440px] space-y-12">
        {/* Desktop Full Width - 1440px */}
        <div className="space-y-3">
          <div className="text-center">
            <h2 className="text-sm font-medium text-gray-900">Team Capacity — Final</h2>
            <p className="text-xs text-gray-500">Desktop: 1440px × 340px</p>
          </div>
          <div className="w-full h-[340px] bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
            <FinalTeamCapacityWidget />
          </div>
        </div>

        {/* Tablet - 1024px */}
        <div className="space-y-3">
          <div className="text-center">
            <p className="text-xs text-gray-500">Tablet: 1024px × 340px</p>
          </div>
          <div className="w-[1024px] h-[340px] bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden mx-auto">
            <FinalTeamCapacityWidget />
          </div>
        </div>

        {/* Small Tablet - 768px */}
        <div className="space-y-3">
          <div className="text-center">
            <p className="text-xs text-gray-500">Small Tablet: 768px × 340px (2-line layout)</p>
          </div>
          <div className="w-[768px] h-[340px] bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden mx-auto">
            <FinalTeamCapacityWidget />
          </div>
        </div>
      </div>
    </div>
  );
}
