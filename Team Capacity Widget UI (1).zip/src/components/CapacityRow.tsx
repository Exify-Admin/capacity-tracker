import React, { useState } from 'react';
import { CapacityBar } from './CapacityBar';
import { CheckCircle2, Ban, Clock, MoreVertical, Loader2 } from 'lucide-react';

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  avatar: string;
  activeTasks: number;
  capacity: number;
  blocked: number;
  overdue: number;
  topTask: string;
}

interface CapacityRowProps {
  member: TeamMember;
  onMarkDone: (memberId: string) => void;
  onToggleBlocked: (memberId: string) => void;
  onSnooze: (memberId: string) => void;
  onReassign: (memberId: string) => void;
  onSetPriority: (memberId: string) => void;
  onOpenInNotion: (memberId: string) => void;
  isSaving?: boolean;
}

export function CapacityRow({
  member,
  onMarkDone,
  onToggleBlocked,
  onSnooze,
  onReassign,
  onSetPriority,
  onOpenInNotion,
  isSaving = false,
}: CapacityRowProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [showReassignModal, setShowReassignModal] = useState(false);
  const [showPriorityMenu, setShowPriorityMenu] = useState(false);

  return (
    <div
      className={`relative grid grid-cols-12 gap-3 items-center py-2.5 px-4 transition-colors ${
        isHovered ? 'bg-gray-50/60' : ''
      } ${isSaving ? 'opacity-50' : ''}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => {
        setIsHovered(false);
        setShowMenu(false);
      }}
    >
      {/* Avatar + Name + Role */}
      <div className="col-span-2 flex items-center gap-2.5">
        <div
          className="w-8 h-8 rounded-full bg-gray-200 flex-shrink-0 overflow-hidden"
          style={{
            backgroundImage: `url(${member.avatar})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        <div className="min-w-0">
          <div className="font-medium text-[13px] text-gray-900 truncate">
            {member.name}
          </div>
          <div className="text-[11px] text-gray-500 truncate">{member.role}</div>
        </div>
      </div>

      {/* Capacity Bar */}
      <div className="col-span-4">
        <CapacityBar
          active={member.activeTasks}
          total={member.capacity}
        />
      </div>

      {/* Status Chips */}
      <div className="col-span-2 flex items-center gap-1.5">
        {member.blocked > 0 && (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-gray-100 text-gray-700 rounded-md text-[11px]">
            <Ban className="w-3 h-3" />
            Blocked {member.blocked}
          </span>
        )}
        {member.overdue > 0 && (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-red-50 text-red-700 rounded-md text-[11px]">
            Overdue {member.overdue}
          </span>
        )}
      </div>

      {/* Top Task Preview */}
      <div className="col-span-3 text-[12px] text-gray-500 truncate">
        Top task: {member.topTask}
      </div>

      {/* Row Actions */}
      <div className="col-span-1 flex items-center justify-end gap-1">
        {isSaving && (
          <div className="flex items-center gap-1.5 mr-2">
            <Loader2 className="w-3 h-3 animate-spin text-gray-400" />
            <span className="text-[11px] text-gray-500">Saving…</span>
          </div>
        )}
        {isHovered && !isSaving && (
          <div className="flex items-center gap-0.5">
            <button
              onClick={() => onMarkDone(member.id)}
              className="p-1.5 hover:bg-gray-200 rounded-md transition-colors group"
              title="Mark Done"
            >
              <CheckCircle2 className="w-4 h-4 text-gray-500 group-hover:text-gray-700" />
            </button>
            <button
              onClick={() => onToggleBlocked(member.id)}
              className="p-1.5 hover:bg-gray-200 rounded-md transition-colors group"
              title="Toggle Blocked"
            >
              <Ban className="w-4 h-4 text-gray-500 group-hover:text-gray-700" />
            </button>
            <button
              onClick={() => onSnooze(member.id)}
              className="p-1.5 hover:bg-gray-200 rounded-md transition-colors group"
              title="Snooze +2 days"
            >
              <Clock className="w-4 h-4 text-gray-500 group-hover:text-gray-700" />
            </button>
            <div className="relative">
              <button
                onClick={() => setShowMenu(!showMenu)}
                className="p-1.5 hover:bg-gray-200 rounded-md transition-colors group"
                title="More actions"
              >
                <MoreVertical className="w-4 h-4 text-gray-500 group-hover:text-gray-700" />
              </button>
              {showMenu && (
                <div className="absolute right-0 top-full mt-1 w-48 bg-white border border-gray-200 rounded-lg shadow-lg py-1 z-10">
                  <button
                    onClick={() => {
                      setShowReassignModal(true);
                      setShowMenu(false);
                    }}
                    className="w-full text-left px-3 py-1.5 text-[13px] text-gray-700 hover:bg-gray-50 transition-colors"
                  >
                    Reassign…
                  </button>
                  <button
                    onClick={() => {
                      setShowPriorityMenu(true);
                      setShowMenu(false);
                    }}
                    className="w-full text-left px-3 py-1.5 text-[13px] text-gray-700 hover:bg-gray-50 transition-colors"
                  >
                    Set Priority…
                  </button>
                  <div className="h-px bg-gray-200 my-1" />
                  <button
                    onClick={() => {
                      onOpenInNotion(member.id);
                      setShowMenu(false);
                    }}
                    className="w-full text-left px-3 py-1.5 text-[13px] text-gray-700 hover:bg-gray-50 transition-colors"
                  >
                    Open Task in Notion →
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Reassign Modal */}
      {showReassignModal && (
        <div
          className="fixed inset-0 bg-black/20 flex items-center justify-center z-50"
          onClick={() => setShowReassignModal(false)}
        >
          <div
            className="bg-white rounded-xl shadow-xl p-4 w-80"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="font-medium text-[14px] text-gray-900 mb-3">
              Reassign Task
            </h3>
            <input
              type="text"
              placeholder="Search teammate…"
              className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-[13px] mb-3"
            />
            <div className="space-y-1 mb-3 max-h-48 overflow-y-auto">
              {['Sarah Chen', 'Marcus Lee', 'Emma Davis', 'Alex Kim'].map((name) => (
                <button
                  key={name}
                  onClick={() => {
                    onReassign(member.id);
                    setShowReassignModal(false);
                  }}
                  className="w-full text-left px-3 py-2 text-[13px] text-gray-700 hover:bg-gray-50 rounded-md transition-colors"
                >
                  {name}
                </button>
              ))}
            </div>
            <div className="flex justify-end">
              <button
                onClick={() => setShowReassignModal(false)}
                className="px-3 py-1.5 text-[13px] text-gray-600 hover:text-gray-800"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Priority Menu */}
      {showPriorityMenu && (
        <div
          className="fixed inset-0 bg-black/20 flex items-center justify-center z-50"
          onClick={() => setShowPriorityMenu(false)}
        >
          <div
            className="bg-white rounded-xl shadow-xl p-4 w-64"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="font-medium text-[14px] text-gray-900 mb-3">
              Set Priority
            </h3>
            <div className="space-y-2">
              {['Low', 'Medium', 'High'].map((priority) => (
                <button
                  key={priority}
                  onClick={() => {
                    onSetPriority(member.id);
                    setShowPriorityMenu(false);
                  }}
                  className="w-full px-3 py-2 text-[13px] text-gray-700 hover:bg-gray-50 rounded-lg border border-gray-200 transition-colors"
                >
                  {priority}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
