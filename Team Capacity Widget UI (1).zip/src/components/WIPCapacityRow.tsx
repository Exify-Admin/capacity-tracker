import React, { useState } from 'react';
import { WIPCapacityBar } from './WIPCapacityBar';
import { CheckCircle2, Ban, Clock, MoreVertical } from 'lucide-react';

export interface WIPTeamMember {
  id: string;
  name: string;
  role: string;
  avatar: string;
  currentProject: string;
  wip: number;
  capacity: number;
  notStarted: number;
  blocked: number;
  overdue: number;
  dueNext: {
    day: string;
    task: string;
  };
}

interface WIPCapacityRowProps {
  member: WIPTeamMember;
  onMarkDone?: (memberId: string) => void;
  onToggleBlocked?: (memberId: string) => void;
  onSnooze?: (memberId: string) => void;
  onMore?: (memberId: string) => void;
}

export function WIPCapacityRow({
  member,
  onMarkDone,
  onToggleBlocked,
  onSnooze,
  onMore,
}: WIPCapacityRowProps) {
  const [isHovered, setIsHovered] = useState(false);
  const percentage = Math.round((member.wip / member.capacity) * 100);

  return (
    <div
      className={`relative transition-colors ${
        isHovered ? 'bg-gray-50/60' : ''
      }`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Desktop layout - single row */}
      <div className="hidden lg:grid grid-cols-12 gap-3 items-center py-2.5 px-4">
        {/* Avatar + Name + Role + Current Project */}
        <div className="col-span-3 flex items-center gap-2.5">
          <div
            className="w-8 h-8 rounded-full bg-gray-200 flex-shrink-0 overflow-hidden"
            style={{
              backgroundImage: `url(${member.avatar})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          />
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <div className="font-medium text-[13px] text-gray-900 truncate">
                {member.name}
              </div>
              <div className="px-2 py-0.5 bg-gray-100 rounded-md text-[10px] text-gray-600 truncate flex-shrink-0">
                Current: {member.currentProject}
              </div>
            </div>
            <div className="text-[11px] text-gray-500 truncate">{member.role}</div>
          </div>
        </div>

        {/* WIP Capacity Bar */}
        <div className="col-span-3">
          <WIPCapacityBar wip={member.wip} total={member.capacity} />
        </div>

        {/* Metrics */}
        <div className="col-span-2 flex flex-col gap-0.5">
          <div className="flex items-center gap-2">
            <span className="text-[13px] text-gray-900">
              WIP {member.wip} / {member.capacity}
            </span>
            <span className={`text-[13px] ${member.wip > member.capacity ? 'font-semibold text-red-600' : 'text-gray-500'}`}>
              {percentage}%
            </span>
          </div>
          <div className="text-[11px] text-gray-500">
            Not Started {member.notStarted}
          </div>
        </div>

        {/* Status Chips */}
        <div className="col-span-2 flex items-center gap-1 flex-wrap">
          {member.blocked > 0 && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-gray-100 text-gray-700 rounded-md text-[11px] whitespace-nowrap">
              <Ban className="w-3 h-3" />
              Blocked {member.blocked}
            </span>
          )}
          {member.overdue > 0 && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-red-50 text-red-700 rounded-md text-[11px] whitespace-nowrap">
              Overdue {member.overdue}
            </span>
          )}
        </div>

        {/* Due Next Preview */}
        <div className="col-span-2 text-[12px] text-gray-500 truncate">
          Due next: <span className="text-gray-700">{member.dueNext.day}</span> • {member.dueNext.task}
        </div>
      </div>

      {/* Tablet/Mobile layout - two lines */}
      <div className="lg:hidden py-2.5 px-4 space-y-2">
        {/* Line 1: Name + Current Project + Metrics */}
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 flex-1 min-w-0">
            <div
              className="w-8 h-8 rounded-full bg-gray-200 flex-shrink-0 overflow-hidden"
              style={{
                backgroundImage: `url(${member.avatar})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
              }}
            />
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <div className="font-medium text-[13px] text-gray-900 truncate">
                  {member.name}
                </div>
                <div className="px-2 py-0.5 bg-gray-100 rounded-md text-[10px] text-gray-600 truncate flex-shrink-0">
                  {member.currentProject}
                </div>
              </div>
              <div className="text-[11px] text-gray-500">{member.role}</div>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <span className="text-[13px] text-gray-900">
              WIP {member.wip} / {member.capacity}
            </span>
            <span className={`text-[13px] ${member.wip > member.capacity ? 'font-semibold text-red-600' : 'text-gray-500'}`}>
              {percentage}%
            </span>
          </div>
        </div>

        {/* Line 2: Bar + Chips */}
        <div className="flex items-center gap-3">
          <div className="flex-1">
            <WIPCapacityBar wip={member.wip} total={member.capacity} />
          </div>
          <div className="flex items-center gap-1 flex-shrink-0">
            {member.blocked > 0 && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-gray-100 text-gray-700 rounded-md text-[11px] whitespace-nowrap">
                <Ban className="w-3 h-3" />
                {member.blocked}
              </span>
            )}
            {member.overdue > 0 && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-red-50 text-red-700 rounded-md text-[11px] whitespace-nowrap">
                {member.overdue}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Row Actions - only show on desktop hover */}
      {isHovered && (
        <div className="hidden lg:flex absolute right-4 top-1/2 -translate-y-1/2 items-center gap-0.5 bg-white/90 backdrop-blur-sm px-1 py-1 rounded-md">
          <button
            onClick={() => onMarkDone?.(member.id)}
            className="p-1.5 hover:bg-gray-200 rounded-md transition-colors group"
            title="Mark Done"
          >
            <CheckCircle2 className="w-4 h-4 text-gray-500 group-hover:text-gray-700" />
          </button>
          <button
            onClick={() => onToggleBlocked?.(member.id)}
            className="p-1.5 hover:bg-gray-200 rounded-md transition-colors group"
            title="Toggle Blocked"
          >
            <Ban className="w-4 h-4 text-gray-500 group-hover:text-gray-700" />
          </button>
          <button
            onClick={() => onSnooze?.(member.id)}
            className="p-1.5 hover:bg-gray-200 rounded-md transition-colors group"
            title="Snooze +2d"
          >
            <Clock className="w-4 h-4 text-gray-500 group-hover:text-gray-700" />
          </button>
          <button
            onClick={() => onMore?.(member.id)}
            className="p-1.5 hover:bg-gray-200 rounded-md transition-colors group"
            title="More"
          >
            <MoreVertical className="w-4 h-4 text-gray-500 group-hover:text-gray-700" />
          </button>
        </div>
      )}
    </div>
  );
}