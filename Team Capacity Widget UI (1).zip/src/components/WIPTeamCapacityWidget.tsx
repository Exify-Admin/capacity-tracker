import React, { useState } from 'react';
import { WIPCapacityRow, WIPTeamMember } from './WIPCapacityRow';
import { LoadingSkeleton } from './LoadingSkeleton';
import { EmptyState } from './EmptyState';
import { Search } from 'lucide-react';

const mockWIPTeamMembers: WIPTeamMember[] = [
  {
    id: '1',
    name: 'Sarah Chen',
    role: 'Design Lead',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
    currentProject: 'Website Refresh',
    wip: 4,
    capacity: 10,
    notStarted: 6,
    blocked: 0,
    overdue: 1,
    dueNext: {
      day: 'Thu',
      task: 'Draft Q1 landing page copy and hero section…',
    },
  },
  {
    id: '2',
    name: 'Marcus Lee',
    role: 'Senior Engineer',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
    currentProject: 'Mobile App',
    wip: 8,
    capacity: 10,
    notStarted: 3,
    blocked: 1,
    overdue: 2,
    dueNext: {
      day: 'Tue',
      task: 'Implement authentication flow for iOS…',
    },
  },
  {
    id: '3',
    name: 'Emma Davis',
    role: 'Marketing Manager',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
    currentProject: 'Product Launch',
    wip: 3,
    capacity: 10,
    notStarted: 5,
    blocked: 0,
    overdue: 0,
    dueNext: {
      day: 'Wed',
      task: 'Prepare email campaign templates…',
    },
  },
  {
    id: '4',
    name: 'Alex Kim',
    role: 'Backend Engineer',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
    currentProject: 'API Platform',
    wip: 11,
    capacity: 10,
    notStarted: 2,
    blocked: 2,
    overdue: 1,
    dueNext: {
      day: 'Mon',
      task: 'Debug rate limiting issues in production…',
    },
  },
  {
    id: '5',
    name: 'Olivia Martinez',
    role: 'Product Designer',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop',
    currentProject: 'Settings Redesign',
    wip: 5,
    capacity: 10,
    notStarted: 4,
    blocked: 0,
    overdue: 0,
    dueNext: {
      day: 'Fri',
      task: 'Create wireframes for navigation flow…',
    },
  },
  {
    id: '6',
    name: 'James Wilson',
    role: 'Operations Lead',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop',
    currentProject: 'Vendor Management',
    wip: 2,
    capacity: 10,
    notStarted: 3,
    blocked: 0,
    overdue: 1,
    dueNext: {
      day: 'Thu',
      task: 'Review vendor contracts and pricing…',
    },
  },
  {
    id: '7',
    name: 'Sophia Taylor',
    role: 'Content Strategist',
    avatar: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop',
    currentProject: 'Social Media',
    wip: 6,
    capacity: 10,
    notStarted: 2,
    blocked: 0,
    overdue: 1,
    dueNext: {
      day: 'Tue',
      task: 'Coordinate Q1 content calendar…',
    },
  },
  {
    id: '8',
    name: 'Daniel Brown',
    role: 'Data Engineer',
    avatar: 'https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=100&h=100&fit=crop',
    currentProject: 'Analytics Dashboard',
    wip: 3,
    capacity: 10,
    notStarted: 4,
    blocked: 0,
    overdue: 0,
    dueNext: {
      day: 'Wed',
      task: 'Optimize database query performance…',
    },
  },
];

export function WIPTeamCapacityWidget() {
  const [teamMembers] = useState(mockWIPTeamMembers);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilters, setActiveFilters] = useState({
    timeframe: 'This Week',
    status: ['In Progress', 'Not Started', 'Overdue'],
  });
  const [isLoading, setIsLoading] = useState(false);

  // Calculate team totals
  const teamTotals = teamMembers.reduce(
    (acc, member) => ({
      wip: acc.wip + member.wip,
      notStarted: acc.notStarted + member.notStarted,
      overdue: acc.overdue + member.overdue,
      blocked: acc.blocked + member.blocked,
    }),
    { wip: 0, notStarted: 0, overdue: 0, blocked: 0 }
  );

  const filteredMembers = teamMembers.filter((member) =>
    member.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleFilter = (status: string) => {
    setActiveFilters((prev) => ({
      ...prev,
      status: prev.status.includes(status)
        ? prev.status.filter((s) => s !== status)
        : [...prev.status, status],
    }));
  };

  return (
    <div className="w-full h-full bg-transparent flex flex-col">
      {/* Header */}
      <div className="px-4 py-3 border-b border-gray-200 flex-shrink-0">
        <div className="flex items-center justify-between mb-2">
          <div>
            <h1 className="font-semibold text-[15px] text-gray-900">Team Capacity</h1>
          </div>
          <div className="flex items-center gap-2">
            {/* Filter Chips */}
            <button className="px-2.5 py-1 bg-gray-100 hover:bg-gray-200 text-[12px] text-gray-700 rounded-md transition-colors">
              {activeFilters.timeframe}
            </button>
            <button
              onClick={() => toggleFilter('In Progress')}
              className={`px-2.5 py-1 text-[12px] rounded-md transition-colors ${
                activeFilters.status.includes('In Progress')
                  ? 'bg-gray-800 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              In Progress
            </button>
            <button
              onClick={() => toggleFilter('Not Started')}
              className={`px-2.5 py-1 text-[12px] rounded-md transition-colors ${
                activeFilters.status.includes('Not Started')
                  ? 'bg-gray-800 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Not Started
            </button>
            <button
              onClick={() => toggleFilter('Overdue')}
              className={`px-2.5 py-1 text-[12px] rounded-md transition-colors ${
                activeFilters.status.includes('Overdue')
                  ? 'bg-gray-800 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Overdue
            </button>
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
              <input
                type="text"
                placeholder="Search teammate…"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1 bg-gray-50 border border-gray-200 rounded-md text-[12px] w-40 focus:outline-none focus:ring-1 focus:ring-gray-300"
              />
            </div>
          </div>
        </div>

        {/* Team Totals Strip */}
        <div className="text-[11px] text-gray-500">
          <span className="mr-3">WIP {teamTotals.wip}</span>
          <span className="mr-3">• Not Started {teamTotals.notStarted}</span>
          <span className="mr-3">• Overdue {teamTotals.overdue}</span>
          <span>• Blocked {teamTotals.blocked}</span>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden">
        {isLoading ? (
          <LoadingSkeleton />
        ) : filteredMembers.length > 0 ? (
          <div className="divide-y divide-gray-100">
            {filteredMembers.map((member) => (
              <WIPCapacityRow
                key={member.id}
                member={member}
                onMarkDone={(id) => console.log('Mark done:', id)}
                onToggleBlocked={(id) => console.log('Toggle blocked:', id)}
                onSnooze={(id) => console.log('Snooze:', id)}
                onMore={(id) => console.log('More:', id)}
              />
            ))}
          </div>
        ) : (
          <EmptyState />
        )}
      </div>
    </div>
  );
}
